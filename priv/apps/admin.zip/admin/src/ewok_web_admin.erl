%%
-module(ewok_web_admin).
-vsn("1.0").
-author('steve@simulacity.com').

-include_lib("ewok/include/ewok.hrl").
-include_lib("ewok/include/esp.hrl").

-behavior(ewok_http_resource).
% http_resource callbacks
-export([filter/1, do/3, resource_info/0]).

%%
%% Resource Callbacks
%%
resource_info() -> [
	{name, "Ewok Web Admin (Wookie)"}
].

%%
filter(_Request) ->  
	ok.
%%
do('GET', Request, Session) -> 
%	?TTY("Login ~p~n", [{Request, Session}]),
	Spec = [
		{title, <<"Ewok AS - Administration">>},
		{menu, menu()},
		{content, [
			#h1{body=[<<"Administration">>]},
			#p{body=[<<"There'll be a dashboard here">>]},
			#grid{
				caption=[<<"Deployment Overview">>],
				header=[<<"Application">>, <<"Version">>, <<"Running">>],
				body=[["ewok", "1.0", "true"]]
			}
		]}
	],
	ewok_admin:page(Spec, Request, Session). %% later generalize on realm/domain

% Require? do(_, _, _) -> not_implemented.
	
menu() ->[
	#ul{body=[
		#li{body=[#a{href="/admin", body=["Overview"]}]},
		#li{body=[#a{href="/admin/deployment", body=["Deployment"]}]},
		#li{body=[#a{href="/doc", body=["Documentation"]}]}
	]} 
].
