%%
-module(ewok_admin).

-include_lib("ewok/include/ewok.hrl").
-include_lib("ewok/include/esp.hrl").

-compile(export_all).

%
page(Spec, _Request, Session) ->
	Title = proplists:get_value(title, Spec, <<"Ewok AS">>),
	Headers = proplists:get_value(headers, Spec, []),
	Menu = proplists:get_value(menu, Spec, []),
	Content = proplists:get_value(content, Spec, []),
	Body = [
		#'div'{id="top", body=[
			#img{id="logo", src="/images/ewok-logo.png"},
			#'div'{id="dock", body=dock(Session)}
		]},
		#'div'{id="page", body=[
			#'div'{id="nav", body=Menu},
			#'div'{id="content", body=Content}
		]},
		#br{clear="all"},
		#'div'{id="footer", body=[
			#hr{},
			#p{body=[<<"Copyright &copy 2009 Simulacity.com. All Rights Reserved.">>]}
		]}
	],
	Stylesheet = #css{path="/default.css"},
	Favicon = #link{rel="icon", href="/favicon.png", type="image/png"},
	#page{title=Title, headers=[Stylesheet,Favicon|Headers], body=Body}.

%
dock(Session) ->
	Username = 
		case Session#session.user of
		undefined -> <<"Guest">>;
		U = #user{} -> 
			{_, Name} = U#user.name,
			list_to_binary(Name)
		end,
	[#span{class="label", body=[
		Username, 
		<<" | ">>,
		#a{href="/admin", body=[<<"Dashboard">>]},
		<<" | ">>,
		#a{href="/", body=[<<"News">>]},
		<<" | ">>,
		#a{href="/doc", body=[<<"Documentation">>]},
		<<" | ">>,
		#a{href="/", body=[<<"About">>]}
	]}].
